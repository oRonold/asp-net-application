﻿namespace Checkpoint2.Models
{
    using Microsoft.EntityFrameworkCore;
    public class Contexto : DbContext
    {

        public DbSet<Produto> Produtos { get; set; }
        public DbSet<Categoria> Categorias { get; set; }

        public Contexto(DbContextOptions<Contexto> options) : base(options)
        {

        }

    }
}
