﻿using Microsoft.AspNetCore.Mvc;

namespace Checkpoint2.Controllers
{
    public class CategoriaController : Controller
    {
        [Route("/categoria/index")]
        public IActionResult Index()
        {
            return View();
        }
    }
}
