﻿using Checkpoint2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Checkpoint2.Controllers
{
    [Route("api/produto")]
    [ApiController]
    public class ProdutoApiController : ControllerBase
    {
        private readonly Contexto _dbContext;

        public ProdutoApiController(Contexto dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var produtos = await _dbContext.Produtos.ToListAsync();
            return Ok(produtos);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Produto produto)
        {
            await _dbContext.Produtos.AddAsync(produto);
            await _dbContext.SaveChangesAsync();
            return Ok(produto);
        }

    }
}
