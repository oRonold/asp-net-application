﻿using Checkpoint2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Checkpoint2.Controllers
{
    [Route("api/categoria")]
    [ApiController]
    public class CategoriaApiController : Controller
    {
        private readonly Contexto _dbContext;

        public CategoriaApiController(Contexto dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var categorias = await _dbContext.Categorias.ToListAsync();
            return Ok(categorias);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Categoria categoria)
        {
            await _dbContext.Categorias.AddAsync(categoria);
            await _dbContext.SaveChangesAsync();
            return Ok(categoria);
        }   


    }
}
